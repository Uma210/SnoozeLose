# Run SnoozeLose

1. Extract `SnoozeLose.zip` and open a terminal in the extracted `SnoozeLose` folder.
2. Use Node.js 20.19.4 or newer and run:

   ```sh
   npm ci
   npm start
   ```

3. Open the Expo server in an Expo SDK 54 development build or a version of Expo Go that supports SDK 54.
4. Choose **Preview Krillion alarm** or one of the word puzzle previews.

The archive contains the app source, bundled artwork and puzzles, and the dependency lockfile. `npm ci` fetches the locked dependencies. The Krillion preview demonstrates vibration and completion while the app is open. The shared system alarm scheduler is a separate part of the app.

Run `node --test src/word-game/rules.test.js src/krillion/rules.test.js` to check both games. The [integration guide](src/krillion/README.md) describes how the alarm scheduler connects to Krillion.
